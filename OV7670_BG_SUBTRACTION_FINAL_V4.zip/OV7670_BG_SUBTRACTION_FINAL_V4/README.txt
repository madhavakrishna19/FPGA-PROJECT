OV7670 + DE2-115 REAL-TIME BACKGROUND SUBTRACTION - FINAL V2
============================================================

FPGA: Cyclone IV E EP4CE115F29C7
Camera: plain 18-pin OV7670 module
Internal frame: 320x240 RGB444
Output: 640x480 VGA (2x scaling)

WHAT CHANGED IN V2
------------------
1. RGB565 camera register colour matrix changed to standard Linux/Arduino values.
2. RGB444 is explicitly disabled; COM15 requests full-range RGB565.
3. SW9 can swap the two RGB565 bytes without recompiling if the module outputs the opposite byte order.
4. Background detection uses weighted luminance + maximum colour-channel difference instead of simple RGB sum.
5. A 3-consecutive-VGA-pixel qualification suppresses small isolated speckles.
6. PCLK/HREF/VSYNC/data activity LEDs are stretched so they are visible.
7. Weak pull-ups are enabled on both SCCB SIOC and SIOD.

CONTROLS
--------
KEY0 : reset / resend OV7670 configuration
KEY1 : capture one complete background frame
SW0  : 0=normal live video, 1=background subtraction
SW1  : 0=foreground in camera colour, 1=foreground white mask
SW2  : VGA colour-bar test pattern
SW8:SW3 : detection threshold (000000 => default 8)
SW9  : RGB565 byte order. START WITH 0. If colours are wrong/green, try 1.

LEDS
----
LEDG0 : camera configuration sequence finished
LEDG1 : valid background captured
LEDG2 : PCLK activity detected
LEDG3 : HREF activity detected
LEDG4 : VSYNC activity detected
LEDG5 : camera data changing
LEDG6 : background capture busy
LEDG7 : subtraction active
LEDG8 : SW9 byte swap selected

OV7670 -> DE2-115 JP5 (UNCHANGED WIRING)
----------------------------------------
D0    -> 1
D1    -> 2
D2    -> 3
D3    -> 4
D4    -> 5
D5    -> 6
D6    -> 7
D7    -> 8
PLK   -> 9
HS    -> 10
VS    -> 13
XLK   -> 14
SCL   -> 15
SDA   -> 16
RE    -> 17
PWDN  -> 18
3.3V  -> 29
GND   -> 30

QUARTUS
-------
1. New project, device EP4CE115F29C7.
2. Top-level entity: bg_subtraction_top
3. Add all .v files and bg_subtraction_top.sdc.
4. Tools -> Tcl Scripts -> run DE2_115_OV7670_BGSub_pins.tcl.
5. Compile.
6. Program bg_subtraction_top.sof.

TEST ORDER
----------
A. SW2=1: verify VGA colour bars. Red/green/blue bars must look correct.
B. SW2=0, SW0=0, SW9=0: verify live camera colour.
C. If live camera is still strongly green/incorrect, toggle SW9=1.
   Use whichever SW9 position gives natural colours.
D. Leave camera fixed for 2-3 seconds so exposure/AWB settles.
E. Keep nobody in view; press KEY1 once. LEDG1 should turn on after capture.
F. Set SW0=1. Background should go black; changed objects/person remain.
G. Increase SW8:SW3 if background noise remains. Decrease if person disappears.
H. SW1=1 gives a white foreground mask.

IMPORTANT
---------
If VGA colour bars themselves have wrong colours, the problem is VGA pin/DAC/display path,
not the camera. If colour bars are correct but camera is green, use SW9 and the corrected
camera register sequence in this project.

FINAL V3 CAPTURE FIX
--------------------
This revision fixes horizontal tearing/block rearrangement by latching CAM_D,
HREF and VSYNC on the falling edge of CAM_PCLK and processing them on the rising
edge, matching the known-working reference timing. It also separates the RAM
write address (wr_addr) from the internal write_index so address/data/write-enable
stay aligned. The OV7670 register table is restored to the exact known-working
reference sequence.

V4 CHANGE - 3x3 MASK CLEANUP
----------------------------
V4 keeps the V3 camera timing and colour setup unchanged.  It adds:
  * default subtraction threshold = 4
  * a true 3x3, 4-of-9 majority foreground filter at 320x240 source resolution
  * a 1-bit 320x240 filtered-mask RAM (~76.8 kbits)
The filter is one VGA frame behind the live image (~16.7 ms), which is normally
not noticeable for this demonstration.  It removes isolated speckles and fills
small holes much better than the previous horizontal-only filter.
